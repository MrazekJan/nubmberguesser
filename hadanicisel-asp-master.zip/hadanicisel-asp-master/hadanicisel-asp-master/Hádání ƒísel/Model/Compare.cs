﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hádání_čísel.Model
{
    public enum Compare
    {
        Smaller,
        Bigger,
        Equal,
        None
    }
}
