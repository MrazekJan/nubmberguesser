﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Hádání_čísel.Model;

namespace Hádání_čísel.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        [BindProperty]
        public int Number { get; set; }
        [BindProperty]
        public int Guess { get; set; }
        [BindProperty]
        public Compare Temp { get; set; }
        [BindProperty]
        public int Top { get; set; }
        [BindProperty]
        public int Bottom { get; set; }
        [BindProperty]
        public int Round { get; set; }


        private Random _random;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
            _random = new Random();

        }
        public void OnGet()
        {
            Top = 100;
            Bottom = 0;
            Round = 0;
            Number = _random.Next(0,100);
            Temp = Compare.None;
        }

        public void OnPost() {
            Round++;
            if (Guess > Number) {
                Temp = Compare.Bigger;
                Top = Guess;

            }
            else if (Guess < Number)
            {
                Temp = Compare.Smaller;
                Bottom = Guess;
            }
            else
            {
                Temp = Compare.Equal;
                Number = _random.Next(0, 100);
                Top = 100;
                Bottom = 0;
                Round = 0;
            }
        }
    }
}
